<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupportSubject extends Model
{
    protected $fillable = ["subject"];
}
