<!-- /.content-wrapper -->
<footer class="main-footer">
  <!-- <div class="pull-right hidden-xs">
    <b>Version</b> 2.3.3
  </div> -->
  <strong>Copyright &copy; 2016-2017 <a href="/admin">Team.edu</a>.</strong> All rights
  reserved.
</footer>