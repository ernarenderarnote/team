<div class="alertdropdown-content">
	<span class="alertcontent-icon">
	<img src="/images/rejectedicon.png"> </span>
	<span class="alertcontent-text"> Sorry, your job request has been <a href="#" class="rejected-link">rejected</a>. If the employer changes their mind, we will let you know. Please feel free to apply to other job positions. </span>
</div>