<div class="alertdropdown-content">
	<span class="alertcontent-icon">
		<img src="/images/congrats.png"></span>
		<span class="alertcontent-text"> Congrats! You have accepted a job request. Your contact info will be shared.</span>
</div>