 <div class="alertdropdown-content">
    <span class="alertcontent-icon">
       <img src="/images/correct.png">
    </span>
    <span class="alertcontent-text"> Congratulations! Your job request has been <a href="" class="approved-link">approved</a>. The employer will now receive your contact details and will reach out to you shortly.
    </span>
 </div>