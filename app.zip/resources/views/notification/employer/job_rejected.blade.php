<div class="alertdropdown-content">
	<span class="alertcontent-icon">
	<img src="/images/rejectedicon.png"> </span>
	<span class="alertcontent-text"> An Educator has 
	<a href="" class="rejected-link">rejected</a>
    your request.  Your contact info will not be shared.</span>
</div>