 <div class="alertdropdown-content">
    <span class="alertcontent-icon">
       <img src="/images/correct.png">
    </span>
    <span class="alertcontent-text">  Applicant <a href="" class="approved-link">Apply</a>  for job 
        {{-- $alert->data['applicant']['first_name']--}}
    </span>
 </div>