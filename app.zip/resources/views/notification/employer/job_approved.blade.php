 <div class="alertdropdown-content">
    <span class="alertcontent-icon">
       <img src="/images/correct.png">
    </span>
    <span class="alertcontent-text">  An Educator has 
       <a href="" class="approved-link">approved</a> your request. Your contact info will now be shared.
    </span>

 </div>