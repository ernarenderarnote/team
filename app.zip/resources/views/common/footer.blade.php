<!-- Footer area -->
  <footer>
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="footer_inner">
                      <div class="row">
                          <div class="col-md-6">
                              <div class="footer_left">
                                    <p>Copyright 2016 Team.Education. All rights reserved.</p>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="footer_right">
                                    <ul>
                                        <li><a href="#">Contact Us</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                    </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div><!-- Container End -->
  </footer>
  <!-- Footer area End-->

