 <!-- Footer area -->
  <footer class="footer-for-inner-page">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <div class="footer_inner">
                      <div class="row">
                          <div class="col-md-12">
                              <div class="footer_left text-center">
                                  <p>Copyright 2016 Team.Education. All rights reserved.</p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div><!-- Container End -->
  </footer>
  <!-- Footer area End-->
  @section('model')
    
  @endsection
