@component('mail::message')

Sorry, your job request has been rejected. If the employer changes their mind, we will let you know. Please feel free to apply to other job positions.

@endcomponent
