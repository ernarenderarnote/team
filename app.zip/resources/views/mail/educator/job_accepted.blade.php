@component('mail::message')

Employer Accepted  

@endcomponent
