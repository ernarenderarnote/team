@component('mail::message')

Congratulations! Your job request has been approved. The employer will now receive your contact details and will reach out to you shortly.

@endcomponent
