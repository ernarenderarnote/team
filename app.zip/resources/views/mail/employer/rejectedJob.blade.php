@component('mail::message')

Applicant Rejected for job

@endcomponent
