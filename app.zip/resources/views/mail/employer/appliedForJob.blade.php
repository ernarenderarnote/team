
@component('mail::message')

New Applicant Apply for job
 
@endcomponent

